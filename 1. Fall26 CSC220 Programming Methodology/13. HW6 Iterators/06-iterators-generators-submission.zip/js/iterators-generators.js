export function* pairwise(iterable) {
    const itr = iterable[Symbol.iterator]();
    let previous = itr.next();
    while (!previous.done) {
        const current = itr.next();
        if (current.done)
            return;
        yield [previous.value, current.value];
        previous = current;
    }
    return;
}
export function* cycle(iterables) {
    const itrs = iterables.map(iterable => iterable[Symbol.iterator]());
    while (itrs.length > 0) {
        for (let i = 0; i < itrs.length; i++) {
            const val = itrs[i].next();
            if (val.done) {
                itrs.splice(i, 1);
                i--;
            }
            else
                yield val.value;
        }
    }
    return;
}
// Declare the BusinessQuery class here.
// Start the declaration with "export class" so that
// it can be imported from other modules.
export class BusinessQuery {
    bizItr;
    constructor(itr) {
        this.bizItr = itr;
    }
    [Symbol.iterator]() {
        return this.bizItr[Symbol.iterator]();
    }
    filter(func) {
        const source = this.bizItr;
        const filtered = {
            *[Symbol.iterator]() {
                for (const biz of source)
                    if (func(biz))
                        yield biz;
            },
        };
        return new BusinessQuery(filtered);
    }
    exclude(func) {
        const source = this.bizItr;
        const excluded = {
            *[Symbol.iterator]() {
                for (const biz of source)
                    if (!func(biz))
                        yield biz;
            },
        };
        return new BusinessQuery(excluded);
    }
    slice(start, end) {
        if (!Number.isInteger(start) || (end !== undefined && !Number.isInteger(end))) {
            throw new SliceError("slice: start and end must be integers");
        }
        const sliceEnd = end === undefined ? Infinity : end;
        if (start < 0 || sliceEnd < 0) {
            throw new SliceError("slice: start and end must be non-negative");
        }
        if (start > sliceEnd) {
            throw new SliceError("slice: start must not be greater than end");
        }
        const source = this.bizItr;
        const sliced = {
            *[Symbol.iterator]() {
                let index = 0;
                for (const biz of source) {
                    if (index >= start && index < sliceEnd)
                        yield biz;
                    index++;
                    if (index >= sliceEnd)
                        break;
                }
            },
        };
        return new BusinessQuery(sliced);
    }
}
export class SliceError extends Error {
}
//# sourceMappingURL=iterators-generators.js.map