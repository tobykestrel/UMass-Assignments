export function composeFunctions(funs) {
    // TODO
    return (x) => {
        const resultsArray = [x];
        if (funs.length == 0)
            throw new Error("funs array is empty");
        for (let i = 0; i < funs.length; i++) {
            if (typeof funs[i] !== "function")
                throw new Error("funs[" + i.toString() + "] is not a function");
            resultsArray.push(funs[i](resultsArray[i]));
        }
        return resultsArray;
    };
}
export function cyclic(values) {
    // TODO
    if (values.length == 0)
        throw new Error("values array is empty");
    let next = 0;
    return () => {
        const value = values[next];
        next++;
        if (next == values.length)
            next = 0;
        return value;
    };
}
export function rateLimiter(func, limit) {
    // TODO
    let timesCalled = 0;
    return (x, y) => {
        if (timesCalled >= limit)
            return undefined;
        timesCalled++;
        return func(x, y);
    };
}
export function byParity(evenFunc, oddFunc) {
    // TODO
    return (n) => {
        return n % 2 === 0 ? evenFunc(n) : oddFunc(n);
    };
}
export function vendingMachine(price, stock) {
    // TODO
    const costOfItem = price;
    let remainingStock = stock;
    return (amount) => {
        if (remainingStock <= 0)
            return undefined;
        if (amount < costOfItem)
            return undefined;
        remainingStock--;
        return Math.round((amount - costOfItem) * 100) / 100;
    };
}
export function wageChange(calcNew) {
    // TODO
    return (startWage, startYr, endYr) => {
        if (startYr > endYr)
            return NaN;
        if (startYr < 1970)
            return NaN;
        if (endYr > 2026)
            return NaN;
        if (startWage < 1)
            return NaN;
        let currentWage = startWage;
        for (let i = startYr + 1; i <= endYr; i++)
            currentWage = calcNew(i, currentWage);
        return currentWage;
    };
}
export function sineSeries(x) {
    // TODO
    let k = -1;
    let add = false;
    let sineVal = 0;
    function factorial(n) {
        if (n < 0)
            return 0;
        if (n == 0)
            return 1;
        return n * factorial(n - 1);
    }
    return (moreTerms = 1) => {
        for (let i = 0; i < moreTerms; i++) {
            k += 2;
            add = !add;
            if (add)
                sineVal += Math.pow(x, k) / factorial(k);
            if (!add)
                sineVal -= Math.pow(x, k) / factorial(k);
        }
        return sineVal;
    };
}
//# sourceMappingURL=closures.js.map