import { jest } from "@jest/globals";
import { Coordinate } from "./geometry.js";
import { Sprite } from "./sprite.js";
import { MainSimulationView } from "./view.js";
describe("MainSimulationView", () => {
    let canvas;
    let drawImage;
    let view;
    let image;
    beforeEach(() => {
        document.body.innerHTML = "";
        canvas = document.createElement("canvas");
        image = document.createElement("img");
        image.id = "testSprite";
        image.width = 100;
        image.height = 50;
        document.body.append(image);
        drawImage = jest.fn();
        jest.spyOn(canvas, "getContext").mockReturnValue({
            drawImage,
        });
        view = new MainSimulationView(canvas);
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    test("draws registered objects at integer coordinates and scaled dimensions", () => {
        view.updateObject("object-1", new Coordinate(12.9, 20.7), new Sprite("testSprite", 0.5));
        view.draw();
        expect(drawImage).toHaveBeenCalledTimes(1);
        expect(drawImage).toHaveBeenCalledWith(image, 12, 20, 50, 25);
    });
    test("replacing an object updates its position and sprite scale", () => {
        view.updateObject("object-1", new Coordinate(0, 0), new Sprite("testSprite"));
        view.updateObject("object-1", new Coordinate(31, 42), new Sprite("testSprite", 0.25));
        view.draw();
        expect(drawImage).toHaveBeenCalledTimes(1);
        expect(drawImage).toHaveBeenCalledWith(image, 31, 42, 25, 12);
    });
    test("removed objects are no longer drawn", () => {
        view.updateObject("object-1", new Coordinate(0, 0), new Sprite("testSprite"));
        view.removeObject("object-1");
        view.draw();
        expect(drawImage).not.toHaveBeenCalled();
    });
});
//# sourceMappingURL=view.test.js.map