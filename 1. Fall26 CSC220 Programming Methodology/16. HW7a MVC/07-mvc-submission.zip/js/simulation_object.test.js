import { Coordinate } from "./geometry.js";
import { agentFactory } from "./simulation_object/agent.js";
import { structureFactory } from "./simulation_object/structure.js";
describe("simulation object factories", () => {
    test("creates the supported agent types", () => {
        const regular = agentFactory("simple_lobster", "regular", new Coordinate(10, 20));
        const sleepy = agentFactory("sleepy_lobster", "sleepy", new Coordinate(30, 40));
        expect(regular.getLocation()).toEqual(new Coordinate(10, 20));
        expect(regular.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
        expect(sleepy.getLocation()).toEqual(new Coordinate(30, 40));
        expect(sleepy.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
    });
    test("rejects unsupported agent types", () => {
        expect(() => agentFactory("unknown", "bad-agent", new Coordinate(0, 0))).toThrow("unsupported agent type: unknown");
    });
    test("regular lobsters remain still until asked to move", () => {
        const lobster = agentFactory("simple_lobster", "still", new Coordinate(5, 6));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(5, 6));
    });
    test("regular lobsters move toward a destination and stop there", () => {
        const lobster = agentFactory("simple_lobster", "moving", new Coordinate(0, 0));
        const destination = new Coordinate(5, 0);
        lobster.startMoving(destination, 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(2, 0));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(4, 0));
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
    });
    test("sleepy lobsters switch to their sleeping sprite on arrival", () => {
        const lobster = agentFactory("sleepy_lobster", "sleepy-mover", new Coordinate(0, 0));
        const destination = new Coordinate(3, 0);
        lobster.startMoving(destination, 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(2, 0));
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterSleeping", scale: 0.25 });
        lobster.startMoving(new Coordinate(10, 0), 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
    });
    test("sleepy lobsters remain still before they start moving", () => {
        const lobster = agentFactory("sleepy_lobster", "sleepy-still", new Coordinate(5, 6));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(5, 6));
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
    });
    test("creates houses and returns their location and sprite", () => {
        const location = new Coordinate(7, 8);
        const house = structureFactory("house", "home", location);
        expect(house.getLocation()).toBe(location);
        expect(house.getSprite()).toEqual({ imageID: "simpleHouse", scale: 1 });
        house.nextTick();
        expect(house.getLocation()).toBe(location);
    });
    test("rejects unsupported structure types", () => {
        expect(() => structureFactory("unknown", "bad-house", new Coordinate(0, 0))).toThrow("unsupported structure type: unknown");
    });
});
//# sourceMappingURL=simulation_object.test.js.map