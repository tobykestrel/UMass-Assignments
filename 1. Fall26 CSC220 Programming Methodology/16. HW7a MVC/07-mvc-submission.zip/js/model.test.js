import { Coordinate } from "./geometry.js";
import { Model } from "./model.js";
import { agentFactory } from "./simulation_object/agent.js";
import { structureFactory } from "./simulation_object/structure.js";
import { View } from "./view.js";
class TestView extends View {
    updates = [];
    removals = [];
    draw() { }
    updateObject(id, location, sprite) {
        this.updates.push({ id, location, sprite });
    }
    removeObject(id) {
        this.removals.push(id);
    }
}
describe("Model", () => {
    const model = Model.getInstance();
    const agentIds = new Set();
    const structureIds = new Set();
    const views = new Set();
    let nextId = 0;
    function addAgent(agent) {
        model.addAgent(agent);
        agentIds.add(agent.id);
        return agent;
    }
    function addStructure(structure) {
        model.addStructure(structure);
        structureIds.add(structure.id);
        return structure;
    }
    function attachView() {
        const view = new TestView();
        model.attach(view);
        views.add(view);
        return view;
    }
    function uniqueId(prefix) {
        nextId += 1;
        return `${prefix}-${nextId}`;
    }
    afterEach(() => {
        for (const view of views)
            model.detach(view);
        views.clear();
        for (const id of agentIds)
            model.removeAgent(id);
        agentIds.clear();
        for (const id of structureIds)
            model.removeStructure(id);
        structureIds.clear();
    });
    test("getInstance returns the singleton", () => {
        expect(Model.getInstance()).toBe(model);
    });
    test("adds agents and broadcasts their initial state", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(12, 34)));
        expect(model.getAgent(agent.id)).toBe(agent);
        expect(view.updates).toEqual([{ id: agent.id, location: new Coordinate(12, 34), sprite: agent.getSprite() }]);
    });
    test("rejects duplicate agents and reports missing agents", () => {
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        expect(() => model.addAgent(agent)).toThrow(`Agent "${agent.id}" already exists`);
        expect(() => model.getAgent(uniqueId("missing"))).toThrow(/Agent ".+" not found/);
        expect(() => model.removeAgent(uniqueId("missing"))).toThrow(/Couldn't remove agent ".+": Not found/);
    });
    test("adds structures and broadcasts their initial state", () => {
        const view = attachView();
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(56, 78)));
        expect(model.getStructure(structure.id)).toBe(structure);
        expect(view.updates).toEqual([
            { id: structure.id, location: new Coordinate(56, 78), sprite: structure.getSprite() },
        ]);
    });
    test("rejects duplicate structures and reports missing structures", () => {
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(0, 0)));
        expect(() => model.addStructure(structure)).toThrow(`Structure "${structure.id}" already exists`);
        expect(() => model.getStructure(uniqueId("missing"))).toThrow(/Structure .+ not found/);
        expect(() => model.removeStructure(uniqueId("missing"))).toThrow(/Couldn't remove structure ".+": Not found/);
    });
    test("broadcasts each object's state after advancing a tick", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(40, 50)));
        agent.startMoving(new Coordinate(10, 0), 2);
        model.nextTick();
        expect(view.updates).toHaveLength(4);
        expect(view.updates[2]).toMatchObject({
            id: agent.id,
            location: new Coordinate(2, 0),
        });
        expect(view.updates[3]).toMatchObject({
            id: structure.id,
            location: new Coordinate(40, 50),
        });
    });
    test("attaching a view sends it existing agents and structures", () => {
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(1, 2)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(3, 4)));
        const view = attachView();
        expect(view.updates.map(({ id }) => id)).toEqual([agent.id, structure.id]);
    });
    test("removing objects notifies attached views", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(0, 0)));
        model.removeAgent(agent.id);
        agentIds.delete(agent.id);
        model.removeStructure(structure.id);
        structureIds.delete(structure.id);
        expect(view.removals).toEqual([agent.id, structure.id]);
        expect(() => model.getAgent(agent.id)).toThrow(`Agent "${agent.id}" not found`);
        expect(() => model.getStructure(structure.id)).toThrow(`Structure ${structure.id} not found`);
    });
    test("detached views no longer receive object updates", () => {
        const view = attachView();
        model.detach(view);
        views.delete(view);
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        model.nextTick();
        model.removeAgent(agent.id);
        agentIds.delete(agent.id);
        expect(view.updates).toHaveLength(0);
        expect(view.removals).toHaveLength(0);
    });
    test("ticks safely when the model has no objects", () => {
        model.nextTick();
    });
});
//# sourceMappingURL=model.test.js.map