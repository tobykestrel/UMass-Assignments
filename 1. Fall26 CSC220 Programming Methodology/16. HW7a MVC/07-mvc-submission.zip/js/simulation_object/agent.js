import { Coordinate, linearInterpolate } from "../geometry.js";
import { Sprite } from "../sprite.js";
import { SimulationObject } from "./simulation_object.js";
export function agentFactory(type, id, initialLocation) {
    switch (type) {
        case "simple_lobster":
            return new SimpleLobster(id, initialLocation);
        case "sleepy_lobster":
            return new SleepyLobster(id, initialLocation);
        default:
            throw new Error("unsupported agent type: " + type);
    }
}
export class Agent extends SimulationObject {
    // TASK: Decide whether startMoving should be abstract or not.
    // Sets this agent's velocity to move towards the
    // specified destination at the given speed.
    coord = new Coordinate(0, 0);
    moving = {
        isMoving: false,
        movingTo: new Coordinate(0, 0),
        moveSpeed: 0,
    };
    constructor(id, initialLocation) {
        super(id);
        this.coord = initialLocation;
    }
    startMoving(destination, speed) {
        this.moving = { isMoving: true, movingTo: destination, moveSpeed: speed };
    }
    getLocation() {
        return this.coord;
    }
    nextTick() {
        // This method should be called on every simulation object
        // each "tick" of the simulation.
        if (this.moving.isMoving) {
            const lI = linearInterpolate(this.getLocation(), this.moving.movingTo, this.moving.moveSpeed);
            this.coord = lI.newLocation;
            if (lI.reachedDestination)
                this.moving.isMoving = false;
        }
    }
}
class SimpleLobster extends Agent {
    img = new Sprite("lobsterRegular", 0.4);
    constructor(id, initialLocation) {
        super(id, initialLocation);
    }
    getSprite() {
        return this.img;
    }
}
// The modifications to the application I made so that I could implement the behaviors of this class:
// I had to change the moving, coord, and img variables from private to protected.
class SleepyLobster extends SimpleLobster {
    sleeping = false;
    constructor(id, initialLocation) {
        super(id, initialLocation);
    }
    nextTick() {
        // This method should be called on every simulation object
        // each "tick" of the simulation.
        if (!this.sleeping && this.moving.isMoving) {
            const lI = linearInterpolate(this.getLocation(), this.moving.movingTo, this.moving.moveSpeed);
            this.coord = lI.newLocation;
            if (lI.reachedDestination) {
                this.moving.isMoving = false;
                this.sleeping = true;
                this.img = new Sprite("lobsterSleeping", 0.25);
            }
        }
    }
}
//# sourceMappingURL=agent.js.map