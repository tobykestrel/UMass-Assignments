import { Sprite } from "../sprite.js";
import { SimulationObject } from "./simulation_object.js";
export function structureFactory(type, id, location) {
    switch (type) {
        case "house":
            return new House(id, location);
        default:
            throw new Error("unsupported structure type: " + type);
    }
}
export class Structure extends SimulationObject {
    location;
    constructor(id, location) {
        super(id);
        this.location = location;
    }
    getLocation() {
        return this.location;
    }
    nextTick() {
        // temp
    }
}
class House extends Structure {
    img = new Sprite("simpleHouse");
    constructor(id, location) {
        super(id, location);
    }
    getSprite() {
        return this.img;
    }
}
//# sourceMappingURL=structure.js.map