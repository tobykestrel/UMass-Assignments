import { jest } from "@jest/globals";
import { Coordinate } from "./geometry.js";
import { Model } from "./model.js";
import { agentFactory } from "./simulation_object/agent.js";
import { structureFactory } from "./simulation_object/structure.js";
import { Sprite } from "./sprite.js";
import { MainSimulationView, View } from "./view.js";
class TestView extends View {
    updates = [];
    removals = [];
    drawCalls = 0;
    draw() {
        this.drawCalls += 1;
    }
    updateObject(id, location, sprite) {
        this.updates.push({ id, location, sprite });
    }
    removeObject(id) {
        this.removals.push(id);
    }
}
describe("Model", () => {
    const model = Model.getInstance();
    const agentIds = new Set();
    const structureIds = new Set();
    const views = new Set();
    let nextId = 0;
    function addAgent(agent) {
        model.addAgent(agent);
        agentIds.add(agent.id);
        return agent;
    }
    function addStructure(structure) {
        model.addStructure(structure);
        structureIds.add(structure.id);
        return structure;
    }
    function attachView() {
        const view = new TestView();
        model.attach(view);
        views.add(view);
        return view;
    }
    function uniqueId(prefix) {
        nextId += 1;
        return `${prefix}-${nextId}`;
    }
    afterEach(() => {
        for (const view of views)
            model.detach(view);
        views.clear();
        for (const id of agentIds)
            model.removeAgent(id);
        agentIds.clear();
        for (const id of structureIds)
            model.removeStructure(id);
        structureIds.clear();
    });
    it("should return the singleton from getInstance", () => {
        expect(Model.getInstance()).toBe(model);
    });
    it("should add agents and broadcast their initial state", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(12, 34)));
        expect(model.getAgent(agent.id)).toBe(agent);
        expect(view.updates).toEqual([{ id: agent.id, location: new Coordinate(12, 34), sprite: agent.getSprite() }]);
    });
    it("should reject duplicate agents and report missing agents", () => {
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        expect(() => model.addAgent(agent)).toThrow(`Agent "${agent.id}" already exists`);
        expect(() => model.getAgent(uniqueId("missing"))).toThrow(/Agent ".+" not found/);
        expect(() => model.removeAgent(uniqueId("missing"))).toThrow(/Couldn't remove agent ".+": Not found/);
    });
    it("should add structures and broadcast their initial state", () => {
        const view = attachView();
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(56, 78)));
        expect(model.getStructure(structure.id)).toBe(structure);
        expect(view.updates).toEqual([
            { id: structure.id, location: new Coordinate(56, 78), sprite: structure.getSprite() },
        ]);
    });
    it("should preserve the starter house-location check", () => {
        const location = new Coordinate(42, 42);
        const house = structureFactory("house", uniqueId("house"), location);
        expect(house.getLocation()).toEqual(location);
        addStructure(house);
    });
    it("should reject duplicate structures and report missing structures", () => {
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(0, 0)));
        expect(() => model.addStructure(structure)).toThrow(`Structure "${structure.id}" already exists`);
        expect(() => model.getStructure(uniqueId("missing"))).toThrow(/Structure .+ not found/);
        expect(() => model.removeStructure(uniqueId("missing"))).toThrow(/Couldn't remove structure ".+": Not found/);
    });
    it("should broadcast each object's state after advancing a tick", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(40, 50)));
        agent.startMoving(new Coordinate(10, 0), 2);
        model.nextTick();
        expect(view.updates).toHaveLength(4);
        expect(view.updates[2]).toMatchObject({
            id: agent.id,
            location: new Coordinate(2, 0),
        });
        expect(view.updates[3]).toMatchObject({
            id: structure.id,
            location: new Coordinate(40, 50),
        });
    });
    it("should send existing agents and structures to an attached view", () => {
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(1, 2)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(3, 4)));
        const view = attachView();
        expect(view.updates.map(({ id }) => id)).toEqual([agent.id, structure.id]);
    });
    it("should notify attached views when removing objects", () => {
        const view = attachView();
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        const structure = addStructure(structureFactory("house", uniqueId("house"), new Coordinate(0, 0)));
        model.removeAgent(agent.id);
        agentIds.delete(agent.id);
        model.removeStructure(structure.id);
        structureIds.delete(structure.id);
        expect(view.removals).toEqual([agent.id, structure.id]);
        expect(() => model.getAgent(agent.id)).toThrow(`Agent "${agent.id}" not found`);
        expect(() => model.getStructure(structure.id)).toThrow(`Structure ${structure.id} not found`);
    });
    it("should stop sending object updates to detached views", () => {
        const view = attachView();
        model.detach(view);
        views.delete(view);
        const agent = addAgent(agentFactory("simple_lobster", uniqueId("lobster"), new Coordinate(0, 0)));
        model.nextTick();
        model.removeAgent(agent.id);
        agentIds.delete(agent.id);
        expect(view.updates).toHaveLength(0);
        expect(view.removals).toHaveLength(0);
    });
    it("should tick safely when the model has no objects", () => {
        model.nextTick();
    });
});
describe("simulation object factories and behavior", () => {
    it("should create supported agent types with their initial location and sprite", () => {
        const regular = agentFactory("simple_lobster", "regular", new Coordinate(10, 20));
        const sleepy = agentFactory("sleepy_lobster", "sleepy", new Coordinate(30, 40));
        expect(regular.getLocation()).toEqual(new Coordinate(10, 20));
        expect(regular.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
        expect(sleepy.getLocation()).toEqual(new Coordinate(30, 40));
        expect(sleepy.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
    });
    it("should reject unsupported agent types", () => {
        expect(() => agentFactory("unknown", "bad-agent", new Coordinate(0, 0))).toThrow("unsupported agent type: unknown");
    });
    it("should keep regular lobsters still until asked to move", () => {
        const lobster = agentFactory("simple_lobster", "still", new Coordinate(5, 6));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(5, 6));
    });
    it("should move regular lobsters toward a destination and stop there", () => {
        const lobster = agentFactory("simple_lobster", "moving", new Coordinate(0, 0));
        const destination = new Coordinate(5, 0);
        lobster.startMoving(destination, 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(2, 0));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(4, 0));
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
    });
    it("should switch sleepy lobsters to their sleeping sprite on arrival", () => {
        const lobster = agentFactory("sleepy_lobster", "sleepy-mover", new Coordinate(0, 0));
        const destination = new Coordinate(3, 0);
        lobster.startMoving(destination, 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(2, 0));
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterSleeping", scale: 0.25 });
        lobster.startMoving(new Coordinate(10, 0), 2);
        lobster.nextTick();
        expect(lobster.getLocation()).toBe(destination);
    });
    it("should keep sleepy lobsters still before they start moving", () => {
        const lobster = agentFactory("sleepy_lobster", "sleepy-still", new Coordinate(5, 6));
        lobster.nextTick();
        expect(lobster.getLocation()).toEqual(new Coordinate(5, 6));
        expect(lobster.getSprite()).toEqual({ imageID: "lobsterRegular", scale: 0.4 });
    });
    it("should create houses and return their location and sprite", () => {
        const location = new Coordinate(7, 8);
        const house = structureFactory("house", "home", location);
        expect(house.getLocation()).toBe(location);
        expect(house.getSprite()).toEqual({ imageID: "simpleHouse", scale: 1 });
        house.nextTick();
        expect(house.getLocation()).toBe(location);
    });
    it("should reject unsupported structure types", () => {
        expect(() => structureFactory("unknown", "bad-house", new Coordinate(0, 0))).toThrow("unsupported structure type: unknown");
    });
});
describe("MainSimulationView", () => {
    let canvas;
    let drawImage;
    let view;
    let image;
    beforeEach(() => {
        document.body.innerHTML = "";
        canvas = document.createElement("canvas");
        image = document.createElement("img");
        image.id = "testSprite";
        image.width = 100;
        image.height = 50;
        document.body.append(image);
        drawImage = jest.fn();
        jest.spyOn(canvas, "getContext").mockReturnValue({
            drawImage,
        });
        view = new MainSimulationView(canvas);
    });
    afterEach(() => {
        jest.restoreAllMocks();
    });
    it("should draw registered objects at integer coordinates and scaled dimensions", () => {
        view.updateObject("object-1", new Coordinate(12.9, 20.7), new Sprite("testSprite", 0.5));
        view.draw();
        expect(drawImage).toHaveBeenCalledTimes(1);
        expect(drawImage).toHaveBeenCalledWith(image, 12, 20, 50, 25);
    });
    it("should update an object's position and sprite scale when replaced", () => {
        view.updateObject("object-1", new Coordinate(0, 0), new Sprite("testSprite"));
        view.updateObject("object-1", new Coordinate(31, 42), new Sprite("testSprite", 0.25));
        view.draw();
        expect(drawImage).toHaveBeenCalledTimes(1);
        expect(drawImage).toHaveBeenCalledWith(image, 31, 42, 25, 12);
    });
    it("should stop drawing removed objects", () => {
        view.updateObject("object-1", new Coordinate(0, 0), new Sprite("testSprite"));
        view.removeObject("object-1");
        view.draw();
        expect(drawImage).not.toHaveBeenCalled();
    });
});
//# sourceMappingURL=starter.test.js.map