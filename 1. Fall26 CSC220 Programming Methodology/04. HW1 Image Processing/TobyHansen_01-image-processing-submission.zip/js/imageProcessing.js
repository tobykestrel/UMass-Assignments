/**
 * Saturates green color in each pixel of an image
 * @param img An image
 * @returns A new image where each pixel has the green channel set to its maximum.
 */
export function saturateGreen(img) {
    // TODO
    const greenImg = img.copy();
    for (let i = 0; i < img.width; i++) {
        for (let j = 0; j < img.height; j++) {
            greenImg.setPixel(i, j, [img.getPixel(i, j)[0], 255, img.getPixel(i, j)[2]]);
        }
    }
    return greenImg;
}
/**
 * Flips the colors of an image
 * @param img An image
 * @returns A new image where each pixel's channel has been
 *  set as the truncated average of the other two
 */
export function flipColors(img) {
    // TODO
    const flippedImg = img.copy();
    for (let i = 0; i < img.width; i++) {
        for (let j = 0; j < img.height; j++) {
            flippedImg.setPixel(i, j, [
                Math.floor((img.getPixel(i, j)[1] + img.getPixel(i, j)[2]) / 2),
                Math.floor((img.getPixel(i, j)[0] + img.getPixel(i, j)[2]) / 2),
                Math.floor((img.getPixel(i, j)[0] + img.getPixel(i, j)[1]) / 2),
            ]);
        }
    }
    return flippedImg;
}
/**
 * Modifies the given `img` such that the value of each pixel
 * in the given line is the result of applying `func` to the
 * corresponding pixel of `img`. If `lineNo` is not a valid line
 * number, then `img` should not be modified.
 * @param img An image
 * @param lineNo A line number
 * @param func A color transformation function
 */
export function mapLine(img, lineNo, func) {
    // TODO
    if (lineNo >= img.height || lineNo < 0)
        return;
    for (let i = 0; i < img.width; i++) {
        img.setPixel(i, lineNo, func(img.getPixel(i, lineNo)));
    }
}
/**
 * The result must be a new image with the same dimensions as `img`.
 * The value of each pixel in the new image should be the result of
 * applying `func` to the corresponding pixel of `img`.
 * @param img An image
 * @param func A color transformation function
 */
export function imageMap(img, func) {
    // TODO
    const newImg = img.copy();
    for (let i = 0; i < img.height; i++)
        mapLine(newImg, i, func);
    return newImg;
}
/**
 * Saturates green color in an image
 * @param img An image
 * @returns A new image where each pixel has the green channel has been set to its maximum.
 */
export function mapToGreen(img) {
    // TODO
    return imageMap(img, (c) => [c[0], 255, c[2]]);
}
/**
 * Flips the colors of an image
 * @param img An image
 * @returns A new image where each pixels channel has been
 *  set as the truncated average of the other two
 */
export function mapFlipColors(img) {
    // TODO
    return imageMap(img, (c) => [
        Math.floor((c[1] + c[2]) / 2),
        Math.floor((c[0] + c[2]) / 2),
        Math.floor((c[0] + c[1]) / 2),
    ]);
}
//# sourceMappingURL=imageProcessing.js.map