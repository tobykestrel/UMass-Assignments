// Lab 8 - Design Patterns and Generators

/**
 * EXERCISE 1
 *
 * Discuss the following questions with your group and submit your answers individually
 * to Gradescope.
 *
 * 1. What is a design pattern? Why might we use one?
 *
 * 2. What is the purpose of the Singleton pattern? What are its key characteristics?
 *
 * 3. Describe the nature of interactions between:
 *    - Model and View
 *    - Model and Controller
 *    - View and Controller
 */

/**
 * EXERCISE 2
 *
 * Implement a generator function that takes in two number iterators, each yielding
 * values in non-decreasing order, and merges them into a single non-decreasing sequence.
 *
 * Your solution should:
 *    - Preserve duplicates and return all values from both iterators.
 *    - Handle empty iterators and cases where one iterator finishes before the other.
 *    - Use O(1) space.
 */

export function* mergedGenerator(it1: Iterator<number>, it2: Iterator<number>): Generator<number> {
  // TODO: Implement this generator.
  let result1 = it1.next();
  let result2 = it2.next();
  while (!result1.done || !result2.done) {
    if (result1.done) {
      yield result2.value;
      result2 = it2.next();
    } else if (result2.done) {
      yield result1.value;
      result1 = it1.next();
    } else if (result1.value <= result2.value) {
      yield result1.value;
      result1 = it1.next();
    } else {
      yield result2.value;
      result2 = it2.next();
    }
  }
}
